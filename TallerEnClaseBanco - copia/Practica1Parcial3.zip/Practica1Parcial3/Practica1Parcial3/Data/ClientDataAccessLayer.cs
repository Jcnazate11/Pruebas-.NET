﻿namespace Practica1Parcial3.Data
{
    public class ClientDataAccessLayer
    {

    }
}
